# WebView JS bridge is not used; nothing to keep.
