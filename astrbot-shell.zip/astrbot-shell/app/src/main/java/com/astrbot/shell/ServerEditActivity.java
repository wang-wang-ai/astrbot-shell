package com.astrbot.shell;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public class ServerEditActivity extends Activity {

    public static final String EXTRA_ID = "server_id";

    private EditText nameInput;
    private EditText urlInput;
    private TextView statusText;
    private Button deleteButton;
    private String editingId;

    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server_edit);

        nameInput = (EditText) findViewById(R.id.input_name);
        urlInput = (EditText) findViewById(R.id.input_url);
        statusText = (TextView) findViewById(R.id.status);
        deleteButton = (Button) findViewById(R.id.btn_delete);

        editingId = getIntent().getStringExtra(EXTRA_ID);
        if (editingId != null) {
            Servers.Server s = Servers.find(this, editingId);
            if (s != null) {
                nameInput.setText(s.name);
                urlInput.setText(s.url);
            }
            deleteButton.setVisibility(View.VISIBLE);
        } else {
            deleteButton.setVisibility(View.GONE);
        }

        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.btn_save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });

        findViewById(R.id.btn_test).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                test();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editingId != null) {
                    Servers.remove(ServerEditActivity.this, editingId);
                    Toast.makeText(ServerEditActivity.this, "已删除", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });
    }

    private void save() {
        String url = Servers.normalizeUrl(urlInput.getText().toString());
        if (url.length() == 0) {
            statusText.setText("请先填写 AstrBot 面板地址，例如 192.168.1.10:6185");
            return;
        }
        String name = nameInput.getText().toString().trim();
        if (name.length() == 0) {
            name = Servers.hostOf(url);
        }
        if (name.length() == 0) {
            name = url;
        }
        String id = editingId != null ? editingId : UUID.randomUUID().toString();
        Servers.put(this, new Servers.Server(id, name, url));
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void test() {
        final String url = Servers.normalizeUrl(urlInput.getText().toString());
        if (url.length() == 0) {
            statusText.setText("请先填写 AstrBot 面板地址");
            return;
        }
        statusText.setText("正在连接 " + url + " …");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String result = probe(url);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        statusText.setText(result);
                    }
                });
            }
        }).start();
    }

    /** 在后台线程里试一次 GET，返回给人看的结果文字。 */
    private static String probe(String url) {
        long start = System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            int code = conn.getResponseCode();
            long ms = System.currentTimeMillis() - start;
            if (code >= 200 && code < 400) {
                return "连接成功（HTTP " + code + "，" + ms + " ms）";
            }
            return "有响应，但状态码是 " + code + "，确认地址和端口对不对";
        } catch (Exception e) {
            return "连不上：" + e.getClass().getSimpleName()
                    + "\n检查手机和服务器是否在同一网络、端口是否放行。";
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
