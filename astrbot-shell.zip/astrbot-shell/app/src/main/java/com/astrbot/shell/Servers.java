package com.astrbot.shell;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 本地保存的 AstrBot 服务器列表（SharedPreferences + JSON）。 */
public final class Servers {

    public static class Server {
        public String id;
        public String name;
        public String url;

        public Server(String id, String name, String url) {
            this.id = id;
            this.name = name;
            this.url = url;
        }
    }

    private static final String PREF = "astrbot_shell";
    private static final String KEY = "servers";

    private Servers() {
    }

    public static List<Server> load(Context ctx) {
        List<Server> out = new ArrayList<Server>();
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, "");
        if (raw == null || raw.length() == 0) {
            return out;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) {
                    continue;
                }
                String url = o.optString("url", "");
                if (url.length() == 0) {
                    continue;
                }
                String id = o.optString("id", "");
                if (id.length() == 0) {
                    id = UUID.randomUUID().toString();
                }
                String name = o.optString("name", "");
                if (name.length() == 0) {
                    name = hostOf(url);
                }
                if (name.length() == 0) {
                    name = url;
                }
                out.add(new Server(id, name, url));
            }
        } catch (Exception ignored) {
            // 数据坏了就当空列表
        }
        return out;
    }

    public static void save(Context ctx, List<Server> list) {
        JSONArray arr = new JSONArray();
        for (Server s : list) {
            JSONObject o = new JSONObject();
            try {
                o.put("id", s.id);
                o.put("name", s.name);
                o.put("url", s.url);
            } catch (Exception ignored) {
            }
            arr.put(o);
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, arr.toString())
                .apply();
    }

    public static Server find(Context ctx, String id) {
        if (id == null) {
            return null;
        }
        for (Server s : load(ctx)) {
            if (id.equals(s.id)) {
                return s;
            }
        }
        return null;
    }

    public static void put(Context ctx, Server server) {
        List<Server> list = load(ctx);
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(server.id)) {
                list.set(i, server);
                replaced = true;
                break;
            }
        }
        if (!replaced) {
            list.add(server);
        }
        save(ctx, list);
    }

    public static void remove(Context ctx, String id) {
        List<Server> list = load(ctx);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).id.equals(id)) {
                list.remove(i);
            }
        }
        save(ctx, list);
    }

    /** 补全 http://，去掉结尾的斜杠。 */
    public static String normalizeUrl(String raw) {
        if (raw == null) {
            return "";
        }
        String u = raw.trim();
        if (u.length() == 0) {
            return "";
        }
        String lower = u.toLowerCase();
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            u = "http://" + u;
        }
        while (u.endsWith("/")) {
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }

    public static String hostOf(String url) {
        try {
            URL u = new URL(url);
            String h = u.getHost();
            return h == null ? "" : h;
        } catch (Exception e) {
            return "";
        }
    }
}
