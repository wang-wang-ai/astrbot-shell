package com.astrbot.shell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {

    private LinearLayout listContainer;
    private TextView emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listContainer = (LinearLayout) findViewById(R.id.list);
        emptyView = (TextView) findViewById(R.id.empty);

        findViewById(R.id.btn_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ServerEditActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        listContainer.removeAllViews();
        List<Servers.Server> servers = Servers.load(this);
        emptyView.setVisibility(servers.isEmpty() ? View.VISIBLE : View.GONE);
        LayoutInflater inflater = LayoutInflater.from(this);
        for (final Servers.Server s : servers) {
            View item = inflater.inflate(R.layout.item_server, listContainer, false);
            ((TextView) item.findViewById(R.id.name)).setText(s.name);
            ((TextView) item.findViewById(R.id.url)).setText(s.url);
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openWebView(s.id);
                }
            });
            item.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showItemMenu(s);
                    return true;
                }
            });
            listContainer.addView(item);
        }
    }

    private void openWebView(String id) {
        Intent i = new Intent(this, WebViewActivity.class);
        i.putExtra(WebViewActivity.EXTRA_ID, id);
        startActivity(i);
    }

    private void showItemMenu(final Servers.Server s) {
        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setItems(new String[]{"编辑", "删除"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            Intent i = new Intent(MainActivity.this, ServerEditActivity.class);
                            i.putExtra(ServerEditActivity.EXTRA_ID, s.id);
                            startActivity(i);
                        } else {
                            Servers.remove(MainActivity.this, s.id);
                            render();
                        }
                    }
                })
                .show();
    }
}
