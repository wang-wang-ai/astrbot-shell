package com.astrbot.shell;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/** AstrBot WebUI 的外壳：同一个站内地址留在应用里，站外链接丢给系统浏览器。 */
public class WebViewActivity extends Activity {

    public static final String EXTRA_ID = "server_id";
    private static final int REQ_FILE = 1001;

    private WebView webView;
    private ProgressBar progress;
    private TextView titleView;
    private View errorView;
    private TextView errorText;
    private ValueCallback<Uri[]> fileCallback;

    private String homeUrl = "";
    private String homeHost = "";
    private String lastUrl = "";
    private String serverName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        String id = getIntent().getStringExtra(EXTRA_ID);
        Servers.Server server = Servers.find(this, id);
        if (server == null) {
            Toast.makeText(this, "找不到这个服务器，请重新添加", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        serverName = server.name;
        homeUrl = server.url;
        homeHost = Servers.hostOf(homeUrl);

        webView = (WebView) findViewById(R.id.webview);
        progress = (ProgressBar) findViewById(R.id.progress);
        titleView = (TextView) findViewById(R.id.title);
        errorView = findViewById(R.id.error_view);
        errorText = (TextView) findViewById(R.id.error_text);

        titleView.setText(serverName);

        findViewById(R.id.btn_back_page).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    finish();
                }
            }
        });

        findViewById(R.id.btn_forward_page).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (webView.canGoForward()) {
                    webView.goForward();
                }
            }
        });

        findViewById(R.id.btn_home).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorView.setVisibility(View.GONE);
                webView.loadUrl(homeUrl);
            }
        });

        findViewById(R.id.btn_reload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorView.setVisibility(View.GONE);
                webView.reload();
            }
        });

        findViewById(R.id.btn_retry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorView.setVisibility(View.GONE);
                webView.loadUrl(lastUrl.length() > 0 ? lastUrl : homeUrl);
            }
        });

        // 长按标题栏：复制地址 / 用浏览器打开
        titleView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                String url = lastUrl.length() > 0 ? lastUrl : homeUrl;
                android.content.ClipboardManager cm =
                        (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", url));
                }
                Toast.makeText(WebViewActivity.this, "已复制地址", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        setupWebView();
        setupDownload();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(homeUrl);
        }
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " AstrBotShell/1.0");

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cm.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUri(request.getUrl());
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                lastUrl = url;
                errorView.setVisibility(View.GONE);
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                lastUrl = url;
                progress.setVisibility(View.GONE);
                String t = view.getTitle();
                if (t != null && t.length() > 0 && !t.startsWith("http")) {
                    titleView.setText(t);
                } else {
                    titleView.setText(serverName);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    progress.setVisibility(View.GONE);
                    String desc = error == null ? "" : String.valueOf(error.getDescription());
                    showError("连不上 AstrBot 面板\n\n" + homeUrl
                            + (desc.length() > 0 ? "\n（" + desc + "）" : "")
                            + "\n\n检查：面板有没有启动、手机和它是不是同一网络、地址和端口对不对。");
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Toast.makeText(WebViewActivity.this, "页面进程异常退出，请重新打开", Toast.LENGTH_LONG).show();
                finish();
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(WebViewActivity.this, "没有可以选文件的应用", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
    }

    private void setupDownload() {
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                if (url.startsWith("blob:") || url.startsWith("data:")) {
                    Toast.makeText(WebViewActivity.this, "这类文件暂时没法下载，可在浏览器里打开面板下载",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                try {
                    String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null && cookie.length() > 0) {
                        req.addRequestHeader("Cookie", cookie);
                    }
                    if (userAgent != null && userAgent.length() > 0) {
                        req.addRequestHeader("User-Agent", userAgent);
                    }
                    req.setTitle(name);
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(req);
                        Toast.makeText(WebViewActivity.this, "开始下载：" + name, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    openExternal(Uri.parse(url));
                }
            }
        });
    }

    /** 站内地址返回 false 交给 WebView；站外和特殊 scheme 返回 true 表示已处理。 */
    private boolean handleUri(Uri uri) {
        if (uri == null) {
            return false;
        }
        String scheme = uri.getScheme();
        scheme = scheme == null ? "" : scheme.toLowerCase();
        if ("http".equals(scheme) || "https".equals(scheme)) {
            String host = uri.getHost();
            host = host == null ? "" : host;
            if (host.equalsIgnoreCase(homeHost)) {
                return false;
            }
            openExternal(uri);
            return true;
        }
        openExternal(uri);
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "没有能打开这个链接的应用", Toast.LENGTH_SHORT).show();
        }
    }

    private void showError(String msg) {
        errorText.setText(msg);
        errorView.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) {
            webView.saveState(outState);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.setWebChromeClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }
}
