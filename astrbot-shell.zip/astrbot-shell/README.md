# AstrBot 控制台（Android 壳）

把手机上要用的 AstrBot 面板装进一个独立 App：点开就是你的 AstrBot WebUI，多台服务器可以分别存着。

- **不含任何 QQ 协议端实现**，也不碰 QQ 客户端。它只负责打开你自己跑着的 AstrBot 面板。
- 无第三方依赖（纯 Android 框架 + Java），编译快、不联网下载库。
- minSdk 24（Android 7.0）/ targetSdk 34。

## 功能

| 功能 | 说明 |
| --- | --- |
| 多服务器 | 可以存多个 AstrBot 面板（家里一台、服务器一台），列表里选 |
| 地址容错 | 少写 `http://` 会自动补；结尾斜杠自动去掉 |
| 测试连接 | 添加时直接测端口通不通，给出 HTTP 状态码和耗时 |
| 站内留在 App | 同域名跳转留在壳里；外链（文档、GitHub 等）交给系统浏览器 |
| 登录态 | Cookie 持久化，面板登录一次之后不用反复登 |
| 文件上传 | 面板里选文件（插件/配置导入）会调系统文件选择器 |
| 下载 | 面板里点下载走系统下载器，进度在通知栏 |
| 出错兜底 | 连不上时给重试按钮 + 排查提示，不会白屏 |
| 长按标题 | 复制当前页面地址 |

## 构建

本工程**没有**提交 Gradle Wrapper（二进制），两种方式：

### A. GitHub Actions（推荐，手机上就能装）

1. 新建一个 GitHub 仓库，把本目录内容 push 上去（默认分支 `main`）。
2. Actions 会自动跑 `Build APK`，跑完在 run 详情页底部下载 artifact `AstrBotShell-debug`。
3. 手机浏览器登录 GitHub 下载 zip，解开得到 `AstrBotShell-debug.apk`，点开安装（允许「安装未知来源应用」）。

想直接拿一个固定链接：打 tag 推上去即可，工作流会把 APK 传进 Release。

```bash
git init
git add .
git commit -m "AstrBot shell app"
git branch -M main
git remote add origin https://github.com/<你的用户名>/astrbot-shell.git
git push -u origin main

# 出 release 包
git tag v1.0.0
git push origin v1.0.0
```

### B. 本地 Android Studio

用 Android Studio 打开本目录（Gradle 8.9 / AGP 8.7.3 / JDK 17），首次打开会自动补 Wrapper，然后
`Build > Build Bundle(s)/APK(s) > Build APK(s)`。

命令行等价：

```bash
gradle :app:assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

## 使用

1. 电脑/服务器上先跑起 AstrBot（面板默认 `6185` 端口，`http://IP:6185`）。
2. 打开 App → 右上角「+ 添加」→ 填地址 → **测试连接** → 保存。
3. 点列表里那台机器，就是 AstrBot 面板。

注意事项：

- 面板别裸挂公网。要用外网就套一层 HTTPS 反代（Cloudflare Tunnel / Nginx + 证书都行），地址填 `https://你的域名`。
- 同一 Wi-Fi 下直连 `http://192.168.x.x:6185` 最省事；跨网段连不上先查防火墙。
- 本 App 开了明文 HTTP（`usesCleartextTraffic`），是为了局域网直连；用 HTTPS 更安全。

## 关于 QQ 侧

这个 App **只做壳**，AstrBot 收到消息靠的是它自己接的协议端。SnowLuma 这种项目被官方下架、发律师函之后，
任何「把 QQ 客户端改成 OneBot」的路子都在风险区，换谁写都一样——建议：

- 用官方开放平台 / 官方机器人，或者接没争议的平台（Telegram、Discord、飞书、微信服务号等）；
- 一定还要用非官方协议端，就单独部署、别和主号绑一起，随时准备号没了。

App 本身不含、也不会调用任何 QQ 协议实现。
